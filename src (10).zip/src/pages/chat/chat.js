import React from 'react'
import './chat.css'

export default function chat() {
  return (
    <div>chat</div>
  )
}
